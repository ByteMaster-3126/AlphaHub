#!/usr/bin/env bash
set -euo pipefail

ROOT="/workspaces/AlphaHub"
SRC="$(cd -- "$(dirname "$0")/AlphaHubProject/AlphaHub-Reconstruction" && pwd)"
DST="$ROOT/AlphaHubProject/AlphaHub-Reconstruction"

echo "Backing up the current Alpha Hub project..."
cp -a "$DST" "${DST}.backup-before-part1-fix-$(date +%Y%m%d-%H%M%S)"

echo "Replacing source with the corrected Part 1 source..."
mkdir -p "$DST"
cp -a "$SRC/." "$DST/"

# Remove only the old backup Kotlin source that would otherwise be compiled.
find "$DST/app/src/main/java/com/alphaimperium/alphahub" -maxdepth 1 -type f \
  -name 'MainActivity.before-part1.kt' -delete

printf 'sdk.dir=/usr/lib/android-sdk\n' > "$DST/local.properties"

cd "$DST"
echo "Building the corrected APK..."
JAVA_HOME=/usr/local/sdkman/candidates/java/21.0.12+1-ms \
ANDROID_HOME=/usr/lib/android-sdk \
gradle :app:assembleDebug

echo
echo "BUILD COMPLETE"
ls -lh "$DST/app/build/outputs/apk/debug/app-debug.apk"
