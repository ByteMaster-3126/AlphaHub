package com.alphaimperium.alphahub

import android.app.Application
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import org.json.JSONArray
import org.json.JSONObject

class HubViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("alpha_hub", 0)
    private val pm = app.packageManager
    private val context = getApplication<Application>()

    var apps by mutableStateOf<List<AppInfo>>(emptyList())
        private set
    var websites by mutableStateOf(loadWebsites())
        private set
    var recentApps by mutableStateOf(loadRecentApps())
        private set
    var recentWebsites by mutableStateOf(loadRecentWebsites())
        private set
    var recentItems by mutableStateOf(loadRecentItems())
        private set
    var customSections by mutableStateOf(loadSections())
        private set
    var quickLaunch by mutableStateOf(loadQuickLaunch())
        private set
    var favoriteAppPackages by mutableStateOf(loadStringList("favorite_apps"))
        private set
    var phoneSettings by mutableStateOf(loadPhoneSettings())
        private set
    var railSlots by mutableStateOf(loadRailSlots())
        private set

    var backgroundUri by mutableStateOf(prefs.getString("background_uri", null))
        private set
    var backgroundType by mutableStateOf(prefs.getString("background_type", "image") ?: "image")
        private set
    var backgroundAnimation by mutableStateOf(prefs.getBoolean("background_animation", true))
        private set
    var backgroundSpeed by mutableStateOf(prefs.getInt("background_speed", 60))
        private set
    var backgroundBrightness by mutableStateOf(prefs.getInt("background_brightness", 60))
        private set

    var animationsEnabled by mutableStateOf(prefs.getBoolean("animations_enabled", true))
        private set
    var compactMode by mutableStateOf(prefs.getBoolean("compact_mode", false))
        private set
    var panelOpacity by mutableStateOf(prefs.getInt("panel_opacity", 92))
        private set
    var recentsEnabled by mutableStateOf(prefs.getBoolean("recents_enabled", true))
        private set
    var bubbleEnabled by mutableStateOf(prefs.getBoolean("bubble_enabled", false))
        private set

    var logoAnimation by mutableStateOf(prefs.getBoolean("logo_animation", true))
        private set
    var titleGlow by mutableStateOf(prefs.getBoolean("title_glow", true))
        private set
    var glassEnabled by mutableStateOf(prefs.getBoolean("glass_enabled", true))
        private set
    var blurEnabled by mutableStateOf(prefs.getBoolean("blur_enabled", true))
        private set
    var neonBorderEnabled by mutableStateOf(prefs.getBoolean("neon_border", true))
        private set
    var subtitleEnabled by mutableStateOf(prefs.getBoolean("subtitle_enabled", true))
        private set
    var subtitleText by mutableStateOf(prefs.getString("subtitle_text", "Nah, I'd Win") ?: "Nah, I'd Win")
        private set
    var titleText by mutableStateOf(prefs.getString("title_text", "Alpha Hub") ?: "Alpha Hub")
        private set
    var logoUri by mutableStateOf(prefs.getString("logo_uri", null))
        private set
    var titleSize by mutableStateOf(prefs.getInt("title_size", 27))
        private set
    var titleColorHex by mutableStateOf(prefs.getString("title_color", "00E5FF") ?: "00E5FF")
        private set
    var voiceSearchEnabled by mutableStateOf(prefs.getBoolean("voice_search", true))
        private set
    var searchHistoryEnabled by mutableStateOf(prefs.getBoolean("search_history", true))
        private set
    var railEnabled by mutableStateOf(prefs.getBoolean("rail_enabled", true))
        private set
    var railEditMode by mutableStateOf(false)
        private set

    val availablePhoneSettings: List<PhoneSettingShortcut> = listOf(
        PhoneSettingShortcut("wifi", "Wi-Fi", "wifi", Settings.ACTION_WIFI_SETTINGS),
        PhoneSettingShortcut("bluetooth", "Bluetooth", "bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS),
        PhoneSettingShortcut("mobile", "Mobile Data", "mobile", Settings.ACTION_WIRELESS_SETTINGS),
        PhoneSettingShortcut("hotspot", "Hotspot", "hotspot", Settings.ACTION_WIRELESS_SETTINGS),
        PhoneSettingShortcut("airplane", "Airplane Mode", "airplane", Settings.ACTION_AIRPLANE_MODE_SETTINGS),
        PhoneSettingShortcut("location", "Location", "location", Settings.ACTION_LOCATION_SOURCE_SETTINGS),
        PhoneSettingShortcut("battery", "Battery", "battery", Settings.ACTION_BATTERY_SAVER_SETTINGS),
        PhoneSettingShortcut("display", "Display", "display", Settings.ACTION_DISPLAY_SETTINGS),
        PhoneSettingShortcut("sound", "Sound", "sound", Settings.ACTION_SOUND_SETTINGS),
        PhoneSettingShortcut("apps", "App Settings", "apps", Settings.ACTION_APPLICATION_SETTINGS),
        PhoneSettingShortcut("storage", "Storage", "storage", Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
        PhoneSettingShortcut("security", "Security", "security", Settings.ACTION_SECURITY_SETTINGS),
        PhoneSettingShortcut("date", "Date & Time", "date", Settings.ACTION_DATE_SETTINGS),
        PhoneSettingShortcut("accessibility", "Accessibility", "accessibility", Settings.ACTION_ACCESSIBILITY_SETTINGS)
    )

    init { refreshApps() }

    fun refreshApps() {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
            .mapNotNull { info ->
                val ai = info.activityInfo.applicationInfo ?: return@mapNotNull null
                AppInfo(
                    packageName = ai.packageName,
                    label = ai.loadLabel(pm).toString(),
                    isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }

        if (favoriteAppPackages.isEmpty()) {
            val preferred = listOf("Chrome", "YouTube", "Play Store", "Settings", "Gmail", "Facebook")
            val initial = preferred.mapNotNull { wanted ->
                apps.firstOrNull { it.label.equals(wanted, true) }?.packageName
            }.take(4)
            favoriteAppPackages = if (initial.isNotEmpty()) initial else apps.take(4).map { it.packageName }
            saveStringList("favorite_apps", favoriteAppPackages)
        } else {
            favoriteAppPackages = favoriteAppPackages.filter { p -> apps.any { it.packageName == p } }
            saveStringList("favorite_apps", favoriteAppPackages)
        }
    }

    fun favoriteApps(): List<AppInfo> = favoriteAppPackages.mapNotNull { p -> apps.firstOrNull { it.packageName == p } }

    fun toggleFavoriteApp(packageName: String) {
        favoriteAppPackages = if (favoriteAppPackages.contains(packageName)) {
            favoriteAppPackages - packageName
        } else {
            favoriteAppPackages + packageName
        }
        saveStringList("favorite_apps", favoriteAppPackages)
    }

    fun moveFavoriteApp(from: Int, to: Int) {
        if (from !in favoriteAppPackages.indices || to !in favoriteAppPackages.indices) return
        val list = favoriteAppPackages.toMutableList()
        val item = list.removeAt(from)
        list.add(to.coerceIn(0, list.size), item)
        favoriteAppPackages = list
        saveStringList("favorite_apps", favoriteAppPackages)
    }

    fun launchApp(info: AppInfo) {
        val intent = pm.getLaunchIntentForPackage(info.packageName) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        recordRecentApp(info)
    }

    fun launchApp(packageName: String) {
        apps.firstOrNull { it.packageName == packageName }?.let(::launchApp)
    }

    fun openWeb(web: WebsiteShortcut) {
        val fixed = if (web.url.startsWith("http://") || web.url.startsWith("https://")) web.url else "https://${web.url}"
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fixed)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (!web.browserPackage.isNullOrBlank() && isPackageInstalled(web.browserPackage)) {
                intent.setPackage(web.browserPackage)
            }
            context.startActivity(intent)
        }
        recordRecentWebsite(web.copy(url = fixed))
    }

    fun addWebsite(name: String, url: String, imageUri: String?, browserPackage: String? = null) {
        val cleanUrl = url.trim()
        if (cleanUrl.isBlank()) return
        val duplicate = websites.any { it.name.equals(name.ifBlank { "Website" }, true) && it.url.equals(cleanUrl, true) }
        if (duplicate) return
        val now = System.currentTimeMillis()
        websites = websites + WebsiteShortcut(now, name.ifBlank { "Website" }, cleanUrl, false, imageUri, browserPackage)
        saveWebsites()
    }

    fun updateWebsite(id: Long, name: String, url: String, imageUri: String?, browserPackage: String?) {
        websites = websites.map {
            if (it.id == id) it.copy(
                name = name.ifBlank { it.name },
                url = url.trim(),
                imageUri = imageUri,
                browserPackage = browserPackage
            ) else it
        }
        saveWebsites()
    }

    fun setWebsiteBrowser(id: Long, browserPackage: String?) {
        websites = websites.map { if (it.id == id) it.copy(browserPackage = browserPackage) else it }
        saveWebsites()
    }

    fun toggleFavorite(id: Long) {
        websites = websites.map { if (it.id == id) it.copy(favorite = !it.favorite) else it }
        saveWebsites()
    }

    fun favoriteWebsites(): List<WebsiteShortcut> = websites.filter { it.favorite }

    fun removeWebsite(id: Long) {
        websites = websites.filterNot { it.id == id }
        quickLaunch = quickLaunch.filterNot { it.type == "web" && it.key == id.toString() }
        saveWebsites()
        saveQuickLaunch()
    }

    fun addQuickLaunchApp(packageName: String) {
        if (quickLaunch.none { it.type == "app" && it.key == packageName }) {
            quickLaunch = quickLaunch + QuickLaunchEntry("app", packageName)
            saveQuickLaunch()
        }
    }

    fun addQuickLaunchWeb(id: Long) {
        if (quickLaunch.none { it.type == "web" && it.key == id.toString() }) {
            quickLaunch = quickLaunch + QuickLaunchEntry("web", id.toString())
            saveQuickLaunch()
        }
    }

    fun removeQuickLaunch(entry: QuickLaunchEntry) {
        quickLaunch = quickLaunch - entry
        saveQuickLaunch()
    }

    fun addSection(name: String, imageUri: String?, appPackages: List<String>, websiteIds: List<Long>) {
        customSections = customSections + CustomSection(System.currentTimeMillis(), name.ifBlank { "My Section" }, imageUri, appPackages, websiteIds)
        saveSections()
    }

    fun deleteSection(id: Long) {
        customSections = customSections.filterNot { it.id == id }
        saveSections()
    }

    fun setBackground(uri: String?, animation: Boolean, speed: Int, brightness: Int, type: String = "image") {
        backgroundUri = uri
        backgroundType = type
        backgroundAnimation = animation
        backgroundSpeed = speed.coerceIn(10, 100)
        backgroundBrightness = brightness.coerceIn(20, 100)
        prefs.edit()
            .putString("background_uri", uri)
            .putString("background_type", type)
            .putBoolean("background_animation", animation)
            .putInt("background_speed", backgroundSpeed)
            .putInt("background_brightness", backgroundBrightness)
            .apply()
    }

    fun setAnimations(value: Boolean) { animationsEnabled = value; prefs.edit().putBoolean("animations_enabled", value).apply() }
    fun setCompact(value: Boolean) { compactMode = value; prefs.edit().putBoolean("compact_mode", value).apply() }
    fun setOpacity(value: Int) { panelOpacity = value.coerceIn(60, 100); prefs.edit().putInt("panel_opacity", panelOpacity).apply() }
    fun setRecents(value: Boolean) { recentsEnabled = value; prefs.edit().putBoolean("recents_enabled", value).apply() }
    fun setBubble(value: Boolean) { bubbleEnabled = value; prefs.edit().putBoolean("bubble_enabled", value).apply() }

    fun setLogoAnimation(v: Boolean) { logoAnimation = v; prefs.edit().putBoolean("logo_animation", v).apply() }
    fun setTitleGlow(v: Boolean) { titleGlow = v; prefs.edit().putBoolean("title_glow", v).apply() }
    fun setGlass(v: Boolean) { glassEnabled = v; prefs.edit().putBoolean("glass_enabled", v).apply() }
    fun setBlur(v: Boolean) { blurEnabled = v; prefs.edit().putBoolean("blur_enabled", v).apply() }
    fun setNeonBorder(v: Boolean) { neonBorderEnabled = v; prefs.edit().putBoolean("neon_border", v).apply() }
    fun setSubtitleEnabled(v: Boolean) { subtitleEnabled = v; prefs.edit().putBoolean("subtitle_enabled", v).apply() }
    fun setSubtitleText(v: String) { subtitleText = v; prefs.edit().putString("subtitle_text", v).apply() }
    fun setTitleText(v: String) { titleText = v; prefs.edit().putString("title_text", v).apply() }
    fun setLogoUri(v: String?) { logoUri = v; prefs.edit().putString("logo_uri", v).apply() }
    fun setTitleSize(v: Int) { titleSize = v.coerceIn(20, 40); prefs.edit().putInt("title_size", titleSize).apply() }
    fun setTitleColorHex(v: String) { titleColorHex = v; prefs.edit().putString("title_color", v).apply() }
    fun setVoiceSearch(v: Boolean) { voiceSearchEnabled = v; prefs.edit().putBoolean("voice_search", v).apply() }
    fun setSearchHistory(v: Boolean) { searchHistoryEnabled = v; prefs.edit().putBoolean("search_history", v).apply() }
    fun setRailEnabled(v: Boolean) { railEnabled = v; prefs.edit().putBoolean("rail_enabled", v).apply() }
    fun toggleRailEditMode() { railEditMode = !railEditMode }

    fun setRailSlot(index: Int, slot: RailSlot) {
        if (index !in railSlots.indices) return
        railSlots = railSlots.toMutableList().also { it[index] = slot }
        saveRailSlots()
    }

    fun clearRailSlot(index: Int) {
        setRailSlot(index, RailSlot())
    }

    fun openPhoneSetting(id: String) {
        val setting = availablePhoneSettings.firstOrNull { it.id == id } ?: return
        runCatching {
            context.startActivity(Intent(setting.action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        recordRecentItem("setting", id, setting.name)
    }

    fun addPhoneSetting(id: String) {
        val item = availablePhoneSettings.firstOrNull { it.id == id } ?: return
        if (phoneSettings.none { it.id == id }) {
            phoneSettings = phoneSettings + item
            savePhoneSettings()
        }
    }

    fun removePhoneSetting(id: String) {
        phoneSettings = phoneSettings.filterNot { it.id == id }
        savePhoneSettings()
    }

    fun clearRecents() {
        recentApps = emptyList()
        recentWebsites = emptyList()
        recentItems = emptyList()
        saveRecentApps(); saveRecentWebsites(); saveRecentItems()
    }

    private fun recordRecentApp(info: AppInfo) {
        if (!recentsEnabled) return
        recentApps = (listOf(RecentApp(info.packageName, info.label)) + recentApps.filterNot { it.packageName == info.packageName }).take(20)
        saveRecentApps()
        recordRecentItem("app", info.packageName, info.label)
    }

    private fun recordRecentWebsite(web: WebsiteShortcut) {
        if (!recentsEnabled) return
        recentWebsites = (listOf(RecentWebsite(web.id, web.name, web.url, web.imageUri)) + recentWebsites.filterNot { it.id == web.id }).take(20)
        saveRecentWebsites()
        recordRecentItem("web", web.id.toString(), web.name)
    }

    private fun recordRecentItem(type: String, key: String, label: String) {
        if (!recentsEnabled) return
        recentItems = (listOf(RecentItem(type, key, label, System.currentTimeMillis())) + recentItems.filterNot { it.type == type && it.key == key }).take(30)
        saveRecentItems()
    }

    private fun loadWebsites(): List<WebsiteShortcut> {
        val raw = prefs.getString("websites", null) ?: return listOf(
            WebsiteShortcut(1, "YouTube", "https://youtube.com", true),
            WebsiteShortcut(2, "Google", "https://google.com", true),
            WebsiteShortcut(3, "ChatGPT", "https://chatgpt.com", true),
            WebsiteShortcut(4, "Netflix", "https://netflix.com", true)
        )
        return runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                WebsiteShortcut(
                    o.getLong("id"), o.getString("name"), o.getString("url"),
                    o.optBoolean("favorite"), o.optString("imageUri").ifBlank { null },
                    o.optString("browserPackage").ifBlank { null }
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun saveWebsites() {
        val arr = JSONArray()
        websites.forEach { w ->
            arr.put(JSONObject().apply {
                put("id", w.id); put("name", w.name); put("url", w.url); put("favorite", w.favorite)
                put("imageUri", w.imageUri ?: ""); put("browserPackage", w.browserPackage ?: "")
            })
        }
        prefs.edit().putString("websites", arr.toString()).apply()
    }

    private fun loadRecentApps(): List<RecentApp> = runCatching {
        val arr = JSONArray(prefs.getString("recent_apps", "[]"))
        List(arr.length()) { i -> val o = arr.getJSONObject(i); RecentApp(o.getString("packageName"), o.getString("label")) }
    }.getOrDefault(emptyList())

    private fun saveRecentApps() {
        val arr = JSONArray(); recentApps.forEach { a -> arr.put(JSONObject().apply { put("packageName", a.packageName); put("label", a.label) }) }
        prefs.edit().putString("recent_apps", arr.toString()).apply()
    }

    private fun loadRecentWebsites(): List<RecentWebsite> = runCatching {
        val arr = JSONArray(prefs.getString("recent_websites", "[]"))
        List(arr.length()) { i -> val o = arr.getJSONObject(i); RecentWebsite(o.getLong("id"), o.getString("name"), o.getString("url"), o.optString("imageUri").ifBlank { null }) }
    }.getOrDefault(emptyList())

    private fun saveRecentWebsites() {
        val arr = JSONArray(); recentWebsites.forEach { w -> arr.put(JSONObject().apply { put("id", w.id); put("name", w.name); put("url", w.url); put("imageUri", w.imageUri ?: "") }) }
        prefs.edit().putString("recent_websites", arr.toString()).apply()
    }

    private fun loadRecentItems(): List<RecentItem> = runCatching {
        val arr = JSONArray(prefs.getString("recent_items", "[]"))
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            RecentItem(o.getString("type"), o.getString("key"), o.getString("label"), o.optLong("timestamp", 0L))
        }
    }.getOrDefault(emptyList())

    private fun saveRecentItems() {
        val arr = JSONArray()
        recentItems.forEach { item ->
            arr.put(JSONObject().apply {
                put("type", item.type); put("key", item.key); put("label", item.label); put("timestamp", item.timestamp)
            })
        }
        prefs.edit().putString("recent_items", arr.toString()).apply()
    }

    private fun loadSections(): List<CustomSection> = runCatching {
        val arr = JSONArray(prefs.getString("sections", "[]"))
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            val appsArray = o.optJSONArray("apps") ?: JSONArray()
            val webArray = o.optJSONArray("web") ?: JSONArray()
            CustomSection(
                o.getLong("id"), o.getString("name"), o.optString("imageUri").ifBlank { null },
                List(appsArray.length()) { j -> appsArray.getString(j) },
                List(webArray.length()) { j -> webArray.getLong(j) }
            )
        }
    }.getOrDefault(emptyList())

    private fun saveSections() {
        val arr = JSONArray(); customSections.forEach { s ->
            val appsArray = JSONArray(); s.appPackages.forEach(appsArray::put)
            val webArray = JSONArray(); s.websiteIds.forEach(webArray::put)
            arr.put(JSONObject().apply { put("id", s.id); put("name", s.name); put("imageUri", s.imageUri ?: ""); put("apps", appsArray); put("web", webArray) })
        }
        prefs.edit().putString("sections", arr.toString()).apply()
    }

    private fun loadQuickLaunch(): List<QuickLaunchEntry> = runCatching {
        val arr = JSONArray(prefs.getString("quick_launch", "[]"))
        List(arr.length()) { i -> val o = arr.getJSONObject(i); QuickLaunchEntry(o.getString("type"), o.getString("key")) }
    }.getOrDefault(emptyList())

    private fun saveQuickLaunch() {
        val arr = JSONArray(); quickLaunch.forEach { q -> arr.put(JSONObject().apply { put("type", q.type); put("key", q.key) }) }
        prefs.edit().putString("quick_launch", arr.toString()).apply()
    }

    private fun loadPhoneSettings(): List<PhoneSettingShortcut> {
        val saved = prefs.getString("phone_settings", null) ?: return availablePhoneSettings.take(3)
        return runCatching {
            val arr = JSONArray(saved)
            List(arr.length()) { i -> availablePhoneSettings.firstOrNull { it.id == arr.getString(i) } }.filterNotNull()
        }.getOrDefault(availablePhoneSettings.take(3))
    }

    private fun savePhoneSettings() {
        val arr = JSONArray(); phoneSettings.forEach { arr.put(it.id) }
        prefs.edit().putString("phone_settings", arr.toString()).apply()
    }

    private fun loadRailSlots(): List<RailSlot> {
        val saved = prefs.getString("rail_slots", null) ?: return List(5) { RailSlot() }
        return runCatching {
            val arr = JSONArray(saved)
            List(5) { i ->
                if (i < arr.length()) {
                    val o = arr.getJSONObject(i)
                    RailSlot(o.optString("type", "empty"), o.optString("key", ""))
                } else RailSlot()
            }
        }.getOrDefault(List(5) { RailSlot() })
    }

    private fun saveRailSlots() {
        val arr = JSONArray()
        railSlots.forEach { slot ->
            arr.put(JSONObject().apply { put("type", slot.type); put("key", slot.key) })
        }
        prefs.edit().putString("rail_slots", arr.toString()).apply()
    }

    private fun loadStringList(key: String): List<String> {
        return runCatching {
            val arr = JSONArray(prefs.getString(key, "[]"))
            List(arr.length()) { i -> arr.getString(i) }
        }.getOrDefault(emptyList())
    }

    private fun saveStringList(key: String, values: List<String>) {
        val arr = JSONArray(); values.forEach(arr::put)
        prefs.edit().putString(key, arr.toString()).apply()
    }

    private fun isPackageInstalled(packageName: String): Boolean =
        runCatching { pm.getApplicationInfo(packageName, 0); true }.getOrDefault(false)
}
