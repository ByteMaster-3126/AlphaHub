package com.alphaimperium.alphahub

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.os.Build
import android.widget.ImageView
import android.widget.VideoView
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Note
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Web
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alphaimperium.alphahub.ui.theme.AlphaHubTheme

private val Bg = Color(0xFF02050D)
private val Surface1 = Color(0xCC071325)
private val Surface2 = Color(0xE70A1C37)
private val Cyan = Color(0xFF00E5FF)
private val Blue = Color(0xFF159CFF)
private val Purple = Color(0xFF8B5CFF)
private val Magenta = Color(0xFFB339FF)
private val Muted = Color(0xFF9EB0D3)

class MainActivity : ComponentActivity() {
    private var recognitionLauncher: androidx.activity.result.ActivityResultLauncher<Intent>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.rgb(2, 5, 13)
        recognitionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
        }
        setContent { AlphaHubTheme { AlphaHubApp(recognitionLauncher) } }
    }
}

@Composable
private fun AlphaHubApp(
    recognitionLauncher: androidx.activity.result.ActivityResultLauncher<Intent>?,
    vm: HubViewModel = viewModel()
) {
    var screen by remember { mutableStateOf(HubScreen.HOME) }
    var search by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize().background(Bg)) {
        NeoBackground(vm)
        Scaffold(containerColor = Color.Transparent) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).statusBarsPadding()
            ) {
                val topLevel = screen in setOf(HubScreen.HOME, HubScreen.TOOLS, HubScreen.APPS, HubScreen.SHORTCUTS)
                if (screen == HubScreen.HOME) {
                    HomeHeader(
                        vm = vm,
                        onSettings = { screen = HubScreen.SETTINGS },
                        onCrown = { screen = HubScreen.TOOLS }
                    )
                }
                Box(Modifier.fillMaxWidth().weight(1f)) {
                    AnimatedContent(targetState = screen, label = "page") { current ->
                        when (current) {
                            HubScreen.HOME -> HomeScreen(vm, search, { search = it }, { screen = it }, { text ->
                                recognitionLauncher?.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, text)
                                })
                            })
                            HubScreen.TOOLS -> ToolsScreen(vm, { screen = HubScreen.HOME }, { screen = HubScreen.ADD_TOOL }, { screen = HubScreen.MORE_FEATURES })
                            HubScreen.APPS -> InstalledAppsScreen(vm, { screen = HubScreen.QUICK_LAUNCH }, { screen = HubScreen.HOME })
                            HubScreen.SHORTCUTS -> ShortcutsScreen(vm, { screen = HubScreen.CUSTOM_SHORTCUT }, { screen = HubScreen.QUICK_LAUNCH }, { screen = HubScreen.HOME })
                            HubScreen.INSTALLED_APPS -> InstalledAppsScreen(vm, { screen = HubScreen.QUICK_LAUNCH }, { screen = HubScreen.HOME })
                            HubScreen.ADD_TOOL -> AddToolScreen(vm, { screen = HubScreen.HOME }, { screen = HubScreen.INSTALLED_APPS }, { screen = HubScreen.QUICK_LAUNCH }, { screen = HubScreen.CUSTOM_SHORTCUT })
                            HubScreen.CUSTOM_SHORTCUT -> CustomShortcutScreen(vm, { screen = HubScreen.SHORTCUTS })
                            HubScreen.QUICK_LAUNCH -> QuickLaunchScreen(vm, { screen = HubScreen.HOME }, { screen = HubScreen.INSTALLED_APPS }, { screen = HubScreen.CUSTOM_SHORTCUT })
                            HubScreen.MORE_FEATURES -> MoreFeaturesScreen(vm, { screen = HubScreen.BACKGROUND }, { screen = HubScreen.SETTINGS })
                            HubScreen.BACKGROUND -> BackgroundScreen(vm, { screen = HubScreen.MORE_FEATURES })
                            HubScreen.SETTINGS -> SettingsScreen(vm, { screen = HubScreen.HOME })
                        }
                    }
                }
                if (topLevel) {
                    BottomNavigation(screen) { screen = it }
                }
            }
        }
    }
}

@Composable
private fun NeoBackground(vm: HubViewModel) {
    val transition = rememberInfiniteTransition(label = "neo")
    val shift by transition.animateFloat(
        0.98f,
        1.06f,
        infiniteRepeatable(
            tween(durationMillis = (2200 - vm.backgroundSpeed * 12).coerceIn(900, 2200), easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "shift"
    )
    Box(
        Modifier.fillMaxSize().graphicsLayer {
            scaleX = if (vm.backgroundAnimation && vm.animationsEnabled) shift else 1f
            scaleY = if (vm.backgroundAnimation && vm.animationsEnabled) shift else 1f
        }
    ) {
        if (vm.backgroundUri != null) {
            BackgroundMedia(vm.backgroundUri!!, vm.backgroundType, Modifier.fillMaxSize(), vm.backgroundBrightness / 100f)
        } else {
            Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF14285A), Color(0xFF0A0D28), Bg), radius = 900f)))
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val p1 = Path().apply {
                    moveTo(-w * .1f, h * .30f)
                    cubicTo(w * .16f, h * (.10f + (shift - 1f) * .8f), w * .34f, h * .48f, w * .58f, h * .24f)
                    cubicTo(w * .80f, h * .02f, w * .92f, h * .16f, w * 1.12f, h * .08f)
                }
                val p2 = Path().apply {
                    moveTo(-w * .1f, h * .76f)
                    cubicTo(w * .15f, h * .92f, w * .42f, h * .58f, w * .64f, h * .76f)
                    cubicTo(w * .84f, h * .94f, w * .92f, h * .62f, w * 1.12f, h * .70f)
                }
                drawPath(p1, brush = Brush.linearGradient(listOf(Cyan, Blue, Purple)), style = Stroke(width = 7f, cap = StrokeCap.Round), alpha = .55f)
                drawPath(p2, brush = Brush.linearGradient(listOf(Purple, Magenta, Blue)), style = Stroke(width = 9f, cap = StrokeCap.Round), alpha = .45f)
            }
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color.Transparent, Color(0x332F80FF), Color(0x443F16A5), Color.Transparent))))
        }
    }
}

@Composable
private fun HomeHeader(vm: HubViewModel, onSettings: () -> Unit, onCrown: () -> Unit) {
    Surface(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        RoundedCornerShape(24.dp),
        color = if (vm.glassEnabled) Color(0x99071125) else Color.Transparent,
        border = if (vm.neonBorderEnabled) BorderStroke(1.dp, BorderBrush()) else null
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val logoModifier = Modifier
                .size(74.dp)
                .clip(CircleShape)
.graphicsLayer { alpha = if (vm.logoAnimation && vm.animationsEnabled) 0.98f else 1f }
            val customLogo = rememberImageBitmap(vm.logoUri)
            if (customLogo != null) {
                Image(customLogo, null, logoModifier, contentScale = ContentScale.Crop)
            } else {
                Image(
                    painterResource(com.alphaimperium.alphahub.R.drawable.alpha_logo),
                    null,
                    logoModifier,
                    contentScale = ContentScale.Crop
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    vm.titleText,
                    fontSize = vm.titleSize.sp,
                    fontWeight = FontWeight.Bold,
                    color = runCatching { Color(android.graphics.Color.parseColor("#${vm.titleColorHex}")) }.getOrDefault(Cyan),
                    modifier = if (vm.titleGlow) Modifier.graphicsLayer { shadowElevation = 10f } else Modifier
                )
                if (vm.subtitleEnabled) {
                    Text(vm.subtitleText, color = Cyan, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            RoundIcon(Icons.Default.Star, onCrown)
            Spacer(Modifier.width(8.dp))
            RoundIcon(Icons.Default.Settings, onSettings)
        }
    }
}

@Composable
private fun RoundIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Surface(
        shape = CircleShape,
        color = Color(0x330A1631),
        border = BorderStroke(1.dp, Brush.linearGradient(listOf(Blue, Purple))),
        modifier = Modifier.size(48.dp)
    ) {
        IconButton(onClick = onClick) { Icon(icon, null, tint = Color(0xFFB9B2FF)) }
    }
}

@Composable
private fun SearchBar(
    value: String,
    onValueChange: (String) -> Unit,
    onVoice: () -> Unit,
    placeholder: String = "Search apps, tools, or websites..."
) {
    TextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        singleLine = true,
        placeholder = { Text(placeholder, color = Muted) },
        leadingIcon = { Icon(Icons.Default.Search, null, tint = Cyan) },
        trailingIcon = { IconButton(onClick = onVoice) { Icon(Icons.Default.Mic, null, tint = Color(0xFFB98BFF)) } },
        colors = TextFieldDefaults.colors(
            focusedContainerColor = Color(0x9909162A),
            unfocusedContainerColor = Color(0x9909162A),
            focusedIndicatorColor = Cyan,
            unfocusedIndicatorColor = Purple,
            cursorColor = Cyan,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
        ),
        shape = RoundedCornerShape(28.dp)
    )
}

@Composable
private fun HomeScreen(
    vm: HubViewModel,
    search: String,
    onSearch: (String) -> Unit,
    navigate: (HubScreen) -> Unit,
    onVoice: (String) -> Unit
) {
    var railEditor by remember { mutableStateOf<Int?>(null) }
    var showPhoneSettings by remember { mutableStateOf(false) }
    val allSearchApps = vm.apps.filter { it.label.contains(search, true) }
    val allSearchWebs = vm.websites.filter { it.name.contains(search, true) || it.url.contains(search, true) }
    val searchSettings = vm.availablePhoneSettings.filter { it.name.contains(search, true) }

    Row(Modifier.fillMaxSize()) {
        if (vm.railEnabled) {
            ActionRail(
                vm = vm,
                navigate = navigate,
                onEditSlot = { railEditor = it }
            )
        }

        Box(Modifier.fillMaxSize().weight(1f)) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    SearchBar(
                        search,
                        onSearch,
                        { if (vm.voiceSearchEnabled) onVoice("Search Alpha Hub") },
                        placeholder = "Universal Search"
                    )
                }

                if (search.isNotBlank()) {
                    item {
                        SectionCard(
                            title = "SEARCH RESULTS",
                            icon = Icons.Default.Search,
                            addText = null,
                            onAdd = {}
                        ) {
                            allSearchApps.take(8).forEach { app ->
                                SearchResultRow(app.label, "App", Icons.Default.GridView) { vm.launchApp(app) }
                            }
                            allSearchWebs.take(8).forEach { web ->
                                SearchResultRow(web.name, "Website", Icons.Default.Language) { vm.openWeb(web) }
                            }
                            searchSettings.take(8).forEach { setting ->
                                SearchResultRow(setting.name, "Phone Setting", Icons.Default.Settings) { vm.openPhoneSetting(setting.id) }
                            }
                            if (allSearchApps.isEmpty() && allSearchWebs.isEmpty() && searchSettings.isEmpty()) {
                                EmptyInline("No matching apps, websites or settings")
                            }
                        }
                    }
                } else {
                    item {
                        SectionCard(
                            title = "FAVORITE APPS",
                            icon = Icons.Default.Star,
                            addText = "+ Add",
                            onAdd = { navigate(HubScreen.APPS) }
                        ) {
                            val favorites = vm.favoriteApps()
                            if (favorites.isEmpty()) EmptyInline("Tap + Add to choose installed apps")
                            else FavoriteAppGrid(favorites, vm)
                            ViewAllButton { navigate(HubScreen.APPS) }
                        }
                    }

                    item {
                        SectionCard(
                            title = "FAVORITE WEBSITES",
                            icon = Icons.Default.Language,
                            addText = "+ Add",
                            onAdd = { navigate(HubScreen.CUSTOM_SHORTCUT) }
                        ) {
                            val favorites = vm.favoriteWebsites().take(4)
                            if (favorites.isEmpty()) EmptyInline("Add a website and mark it as a favorite")
                            else WebsiteStrip(favorites, vm, showFavorites = true)
                            ViewAllButton { navigate(HubScreen.SHORTCUTS) }
                        }
                    }

                    item {
                        SectionCard(
                            title = "RECENT",
                            icon = Icons.Default.History,
                            addText = "Clear",
                            onAdd = { vm.clearRecents() }
                        ) {
                            val items = vm.recentItems.take(8)
                            if (items.isEmpty()) EmptyInline("Launch an app or open a website through Alpha Hub")
                            else RecentCombinedGrid(items, vm)
                            if (vm.recentItems.size > 8) ViewAllButton { navigate(HubScreen.SHORTCUTS) }
                        }
                    }

                    item {
                        SectionCard(
                            title = "PHONE SETTINGS",
                            icon = Icons.Default.Tune,
                            addText = "+ Add",
                            onAdd = { showPhoneSettings = true }
                        ) {
                            PhoneSettingsStrip(vm.phoneSettings, vm)
                        }
                    }

                    vm.customSections.forEach { section ->
                        item(key = "section-${section.id}") {
                            SectionCard(
                                title = section.name,
                                icon = Icons.Default.Build,
                                addText = null,
                                onAdd = {}
                            ) {
                                if (section.imageUri != null) {
                                    rememberImageBitmap(section.imageUri)?.let { bitmap ->
                                        Image(bitmap, null, Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
                                        Spacer(Modifier.height(8.dp))
                                    }
                                }
                                val sectionApps = section.appPackages.mapNotNull { p -> vm.apps.firstOrNull { it.packageName == p } }
                                if (sectionApps.isNotEmpty()) AppStrip(sectionApps, vm)
                                val sectionWebs = section.websiteIds.mapNotNull { id -> vm.websites.firstOrNull { it.id == id } }
                                if (sectionWebs.isNotEmpty()) WebsiteStrip(sectionWebs, vm, true)
                            }
                        }
                    }
                }
            }
        }
    }

    railEditor?.let { index ->
        RailEditorDialog(
            vm = vm,
            index = index,
            onDismiss = { railEditor = null }
        )
    }
    if (showPhoneSettings) {
        PhoneSettingsPickerDialog(vm) { showPhoneSettings = false }
    }
}

@Composable
private fun PhoneSettingsPickerDialog(vm: HubViewModel, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Phone Settings on Home") },
        text = {
            LazyColumn(Modifier.height(420.dp)) {
                items(vm.availablePhoneSettings) { setting ->
                    val selected = vm.phoneSettings.any { it.id == setting.id }
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            if (selected) vm.removePhoneSetting(setting.id) else vm.addPhoneSetting(setting.id)
                        }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(phoneSettingIcon(setting.iconKey), null, tint = Cyan)
                        Spacer(Modifier.width(10.dp))
                        Text(setting.name, Modifier.weight(1f))
                        Text(if (selected) "Added" else "Add", color = if (selected) Cyan else Muted, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

@Composable
private fun FavoriteAppGrid(apps: List<AppInfo>, vm: HubViewModel) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        modifier = Modifier.height((if (apps.size > 4) 174 else 94).dp),
        userScrollEnabled = false,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(apps.take(8)) { AppTile(it, vm) }
    }
}

@Composable
private fun SearchResultRow(
    title: String,
    type: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Surface(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { onClick() },
        RoundedCornerShape(14.dp),
        color = Surface2,
        border = BorderStroke(1.dp, Color(0xFF1D4F9C))
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(type, color = Muted, fontSize = 11.sp)
            }
            Icon(Icons.Default.OpenInNew, null, tint = Cyan, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun RecentCombinedGrid(items: List<RecentItem>, vm: HubViewModel) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        modifier = Modifier.height(if (items.size > 4) 174.dp else 88.dp),
        userScrollEnabled = false,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(items.take(8)) { item ->
            if (item.type == "app") {
                vm.apps.firstOrNull { it.packageName == item.key }?.let { AppTile(it, vm) }
            } else {
                vm.websites.firstOrNull { it.id.toString() == item.key }?.let { WebsiteTile(it, vm, false) }
            }
        }
    }
}

@Composable
private fun PhoneSettingsStrip(settings: List<PhoneSettingShortcut>, vm: HubViewModel) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        settings.forEach { setting ->
            Surface(
                Modifier.width(112.dp).clickable { vm.openPhoneSetting(setting.id) },
                RoundedCornerShape(16.dp),
                color = Surface2,
                border = BorderStroke(1.dp, Color(0xFF1D62B4))
            ) {
                Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(phoneSettingIcon(setting.iconKey), null, tint = Cyan, modifier = Modifier.size(38.dp))
                    Spacer(Modifier.height(5.dp))
                    Text(setting.name, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
    }
}

private fun phoneSettingIcon(key: String): androidx.compose.ui.graphics.vector.ImageVector = when (key) {
    "wifi" -> Icons.Default.WifiTethering
    "bluetooth" -> Icons.Default.Bolt
    "mobile" -> Icons.Default.Speed
    "hotspot" -> Icons.Default.WifiTethering
    "airplane" -> Icons.Default.LiveTv
    "location" -> Icons.Default.Language
    "battery" -> Icons.Default.Bolt
    "display" -> Icons.Default.Image
    "sound" -> Icons.Default.LiveTv
    "apps" -> Icons.Default.GridView
    "storage" -> Icons.Default.Save
    "security" -> Icons.Default.Lock
    else -> Icons.Default.Settings
}

@Composable
private fun ActionRail(
    vm: HubViewModel,
    navigate: (HubScreen) -> Unit,
    onEditSlot: (Int) -> Unit
) {
    Surface(
        Modifier.width(88.dp).fillMaxHeight().padding(start = 8.dp, top = 8.dp, bottom = 8.dp),
        RoundedCornerShape(30.dp),
        color = Color(0xD9040C1B),
        border = BorderStroke(1.dp, if (vm.neonBorderEnabled) Color.White else Color(0xFF1A3B70))
    ) {
        Column(
            Modifier.fillMaxSize().padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            RailAction(Icons.Default.Build, "Tools") { navigate(HubScreen.TOOLS) }
            RailAction(Icons.Default.Translate, "Screen\ntranslation") { navigate(HubScreen.TOOLS) }
            vm.railSlots.forEachIndexed { index, slot ->
                RailSlotView(slot, vm, index, onEditSlot)
            }
            Spacer(Modifier.weight(1f))
            RailAction(Icons.Default.Edit, if (vm.railEditMode) "Done" else "Edit") { vm.toggleRailEditMode() }
            RailAction(Icons.Default.ArrowBack, "Back") { navigate(HubScreen.HOME) }
        }
    }
}

@Composable
private fun RailAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier.width(72.dp).clip(RoundedCornerShape(18.dp)).clickable { onClick() }.padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(Modifier.size(52.dp), RoundedCornerShape(16.dp), color = Color(0xCC0A2143), border = BorderStroke(1.dp, Blue)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Cyan, modifier = Modifier.size(28.dp)) }
        }
        Text(label, color = Color(0xFFD3E1FF), fontSize = 10.sp, maxLines = 2)
    }
}

@Composable
private fun RailSlotView(slot: RailSlot, vm: HubViewModel, index: Int, onEditSlot: (Int) -> Unit) {
    val content: Pair<androidx.compose.ui.graphics.vector.ImageVector, String> = when (slot.type) {
        "app" -> Icons.Default.GridView to (vm.apps.firstOrNull { it.packageName == slot.key }?.label ?: "App")
        "web" -> Icons.Default.Language to (vm.websites.firstOrNull { it.id.toString() == slot.key }?.name ?: "Website")
        "setting" -> Icons.Default.Settings to (vm.availablePhoneSettings.firstOrNull { it.id == slot.key }?.name ?: "Setting")
        else -> Icons.Default.Add to ""
    }
    val action: () -> Unit = if (vm.railEditMode) ({ onEditSlot(index) }) else ({
        when (slot.type) {
            "app" -> vm.launchApp(slot.key)
            "web" -> vm.websites.firstOrNull { it.id.toString() == slot.key }?.let(vm::openWeb)
            "setting" -> vm.openPhoneSetting(slot.key)
            else -> onEditSlot(index)
        }
    })
    Column(Modifier.width(72.dp).clip(RoundedCornerShape(18.dp)).clickable { action() }.padding(vertical = 3.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(
            Modifier.size(52.dp),
            RoundedCornerShape(16.dp),
            color = if (slot.type == "empty") Color(0x6610274C) else Color(0xCC0A2143),
            border = BorderStroke(1.dp, if (slot.type == "empty") Color(0xFF214F8D) else Cyan)
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(content.first, null, tint = if (slot.type == "empty") Muted else Cyan, modifier = Modifier.size(26.dp)) }
        }
        Text(if (content.second.isBlank()) "Slot ${index + 1}" else content.second.take(10), color = Muted, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun RailEditorDialog(vm: HubViewModel, index: Int, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Customize Rail Slot ${index + 1}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { vm.clearRailSlot(index); onDismiss() }) { Text("Empty slot") }
                Text("Apps", color = Cyan, fontWeight = FontWeight.Bold)
                vm.apps.take(8).forEach { app ->
                    TextButton(onClick = { vm.setRailSlot(index, RailSlot("app", app.packageName)); onDismiss() }, modifier = Modifier.fillMaxWidth()) {
                        Text(app.label, modifier = Modifier.fillMaxWidth())
                    }
                }
                Text("Websites", color = Cyan, fontWeight = FontWeight.Bold)
                vm.websites.take(6).forEach { web ->
                    TextButton(onClick = { vm.setRailSlot(index, RailSlot("web", web.id.toString())); onDismiss() }, modifier = Modifier.fillMaxWidth()) {
                        Text(web.name, modifier = Modifier.fillMaxWidth())
                    }
                }
                Text("Phone Settings", color = Cyan, fontWeight = FontWeight.Bold)
                vm.availablePhoneSettings.take(6).forEach { setting ->
                    TextButton(onClick = { vm.setRailSlot(index, RailSlot("setting", setting.id)); onDismiss() }, modifier = Modifier.fillMaxWidth()) {
                        Text(setting.name, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun SectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    addText: String?,
    onAdd: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
        shape = RoundedCornerShape(24.dp),
        color = Surface1,
        border = BorderStroke(1.dp, Brush.linearGradient(listOf(Blue, Color(0xFF3C56D9), Purple))),
        shadowElevation = 12.dp
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Cyan, modifier = Modifier.size(25.dp))
                Spacer(Modifier.width(10.dp))
                Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                if (addText != null) {
                    TextButton(onClick = onAdd) { Text(addText, color = Purple, fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun AppStrip(apps: List<AppInfo>, vm: HubViewModel) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        apps.forEach { app -> AppTile(app, vm) }
    }
}

@Composable
private fun RecentAppsStrip(apps: List<RecentApp>, vm: HubViewModel) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        apps.forEach { recent ->
            vm.apps.firstOrNull { it.packageName == recent.packageName }?.let { AppTile(it, vm) }
        }
    }
}

@Composable
private fun AppTile(app: AppInfo, vm: HubViewModel) {
    val context = LocalContext.current
    val bitmap = remember(app.packageName) {
        runCatching { context.packageManager.getApplicationIcon(app.packageName).toBitmap(96, 96).asImageBitmap() }.getOrNull()
    }
    Surface(
        modifier = Modifier.width(92.dp).clickable { vm.launchApp(app) },
        shape = RoundedCornerShape(16.dp),
        color = Surface2,
        border = BorderStroke(1.dp, Color(0xFF1D62B4))
    ) {
        Column(Modifier.padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (bitmap != null) Image(bitmap, null, Modifier.size(42.dp).clip(RoundedCornerShape(11.dp)))
            else Box(Modifier.size(42.dp).background(Blue, RoundedCornerShape(11.dp)))
            Spacer(Modifier.height(5.dp))
            Text(app.label.take(14), fontSize = 11.sp, maxLines = 1)
        }
    }
}

@Composable
private fun WebsiteStrip(webs: List<WebsiteShortcut>, vm: HubViewModel, showFavorites: Boolean) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        webs.forEach { web -> WebsiteTile(web, vm, showFavorites) }
    }
}

@Composable
private fun WebsiteTile(web: WebsiteShortcut, vm: HubViewModel, showFavorite: Boolean) {
    Surface(
        modifier = Modifier.width(102.dp),
        shape = RoundedCornerShape(18.dp),
        color = Surface2,
        border = BorderStroke(1.dp, Color(0xFF234E96))
    ) {
        Box(Modifier.clickable { vm.openWeb(web) }) {
            Column(Modifier.padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(contentAlignment = Alignment.TopEnd) {
                    WebsiteIcon(web, Modifier.size(46.dp))
                    if (showFavorite) {
                        IconButton(onClick = { vm.toggleFavorite(web.id) }, modifier = Modifier.size(28.dp)) {
                            Icon(if (web.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Color(0xFFFFC928), modifier = Modifier.size(18.dp))
                        }
                    }
                }
                Spacer(Modifier.height(5.dp))
                Text(web.name.take(14), fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun WebsiteIcon(web: WebsiteShortcut, modifier: Modifier) {
    val image = rememberImageBitmap(web.imageUri)
    if (image != null) {
        Image(image, null, modifier.clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
    } else {
        val icon = when (web.name.lowercase()) {
            "youtube" -> Icons.Default.Bolt
            "google" -> Icons.Default.Search
            "chatgpt" -> Icons.Default.AutoAwesome
            "netflix" -> Icons.Default.LiveTv
            else -> Icons.Default.Language
        }
        Surface(modifier = modifier, shape = RoundedCornerShape(12.dp), color = Color(0xFF0D284A), border = BorderStroke(1.dp, Blue)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Cyan, modifier = Modifier.size(28.dp)) }
        }
    }
}

@Composable
private fun RecentWebStrip(webs: List<RecentWebsite>, vm: HubViewModel) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        webs.forEach { recent ->
            val web = vm.websites.firstOrNull { it.id == recent.id } ?: WebsiteShortcut(recent.id, recent.name, recent.url, false, recent.imageUri)
            WebsiteTile(web, vm, false)
        }
    }
}

@Composable
private fun ViewAllButton(onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, border = BorderStroke(1.dp, Color(0xFF2559A7)), modifier = Modifier.padding(top = 8.dp)) { Text("View all", color = Cyan) }
}

@Composable
private fun EmptyInline(text: String) { Text(text, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(8.dp)) }

@Composable
private fun PageHeader(title: String, subtitle: String? = null, onBack: () -> Unit, action: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Cyan) }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = Cyan)
        }
        action?.invoke()
    }
}

@Composable
private fun ToolsScreen(vm: HubViewModel, onBack: () -> Unit, onAdd: () -> Unit, onFeatures: () -> Unit) {
    val tools = listOf(
        HubTool("translate", "Screen Translation", "Translate text on screen", "translate"),
        HubTool("screenshot", "Screenshot", "Capture your screen", "screenshot"),
        HubTool("qr", "QR Scanner", "Scan QR codes", "qr"),
        HubTool("search", "Web Search", "Search anything", "search"),
        HubTool("lock", "App Lock", "Protect your apps", "lock"),
        HubTool("notes", "Notes", "Quick notes", "notes")
    )
    Column(Modifier.fillMaxSize()) {
        PageHeader("Convenient Tools", "Quick tools for everyday use", onBack, action = { RoundSmallAdd(onAdd) })
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tools) { tool -> ToolRow(tool) }
            item {
                PrimaryGradientButton("＋ Add Tool", onAdd)
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onFeatures, modifier = Modifier.fillMaxWidth()) { Text("Open More Features", color = Cyan) }
            }
        }
    }
}

@Composable
private fun ToolRow(tool: HubTool) {
    val icon = when (tool.iconKey) {
        "translate" -> Icons.Default.Translate
        "screenshot" -> Icons.Default.Image
        "qr" -> Icons.Default.QrCodeScanner
        "search" -> Icons.Default.Search
        "lock" -> Icons.Default.Lock
        else -> Icons.Default.Note
    }
    Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), color = Surface2, border = BorderStroke(1.dp, Color(0xFF1D4C8E))) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(Brush.linearGradient(listOf(Purple, Blue)), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Color.White)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(tool.name, fontWeight = FontWeight.SemiBold); Text(tool.description, fontSize = 11.sp, color = Muted) }
            Icon(Icons.Default.ArrowForward, null, tint = Color(0xFF8BB3FF))
        }
    }
}

@Composable
private fun AddToolScreen(vm: HubViewModel, onBack: () -> Unit, onInstalled: () -> Unit, onQuick: () -> Unit, onShortcut: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    var name by remember { mutableStateOf("My Tools") }
    var selectedImage by remember { mutableStateOf<String?>(null) }
    var selectedApps by remember { mutableStateOf(setOf<String>()) }
    var selectedWebs by remember { mutableStateOf(setOf<Long>()) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> selectedImage = uri?.toString() }

    Column(Modifier.fillMaxSize()) {
        PageHeader("Add Tool", onBack = onBack, action = { RoundSmallAdd { } })
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
            Tab(tab == 0, { tab = 0 }, text = { Text("Custom Section") })
            Tab(tab == 1, { tab = 1 }, text = { Text("Quick Launch") })
        }
        if (tab == 0) {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Surface(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp), color = Surface1, border = BorderStroke(1.dp, Color(0xFF224B91))) {
                        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Section Image", fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                            Spacer(Modifier.height(8.dp))
                            if (selectedImage != null) {
                                rememberImageBitmap(selectedImage)?.let { Image(it, null, Modifier.size(92.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop) }
                            } else Box(Modifier.size(92.dp).background(Color(0xFF0B2343), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Image, null, tint = Cyan, modifier = Modifier.size(42.dp)) }
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = { imagePicker.launch("image/*") }) { Text("Change Image") }
                        }
                    }
                }
                item {
                    Text("Section Name", fontWeight = FontWeight.SemiBold)
                    TextField(value = name, onValueChange = { name = it }, modifier = Modifier.fillMaxWidth(), leadingIcon = { Icon(Icons.Default.Edit, null) }, shape = RoundedCornerShape(14.dp), colors = fieldColors())
                }
                item {
                    Text("Select Apps / Shortcuts", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("Apps", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    vm.apps.take(12).forEach { app ->
                        PickerRow(app.label, selectedApps.contains(app.packageName), {
                            selectedApps = if (selectedApps.contains(app.packageName)) selectedApps - app.packageName else selectedApps + app.packageName
                        })
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Website shortcuts", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    vm.websites.forEach { web ->
                        PickerRow(web.name, selectedWebs.contains(web.id), {
                            selectedWebs = if (selectedWebs.contains(web.id)) selectedWebs - web.id else selectedWebs + web.id
                        })
                    }
                }
                item { PrimaryGradientButton("Save", { vm.addSection(name, selectedImage, selectedApps.toList(), selectedWebs.toList()); onBack() }) }
            }
        } else {
            QuickLaunchScreen(vm, onBack, onInstalled, onShortcut)
        }
    }
}

@Composable
private fun PickerRow(title: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { onClick() },
        RoundedCornerShape(14.dp),
        color = if (selected) Color(0xAA12406E) else Color(0x990A1930),
        border = BorderStroke(1.dp, if (selected) Cyan else Color(0xFF1C467F))
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(if (selected) Cyan else Color.Transparent).then(Modifier.padding(1.dp)).border(1.dp, if (selected) Cyan else Color(0xFF496791), CircleShape))
            Spacer(Modifier.width(10.dp))
            Text(title, modifier = Modifier.weight(1f), fontSize = 12.sp)
            Text(if (selected) "Selected" else "Add", color = if (selected) Cyan else Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SelectableRow(title: String, desc: String, onClick: () -> Unit, selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onClick() }, RoundedCornerShape(16.dp), color = if (selected) Color(0xAA12355B) else Surface2, border = BorderStroke(1.dp, Color(0xFF1B4D93))) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(desc, color = Muted, fontSize = 11.sp) }
            Icon(Icons.Default.ArrowForward, null, tint = Color.White)
        }
    }
}

@Composable
private fun InstalledAppsScreen(vm: HubViewModel, onQuick: () -> Unit, onBack: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    val list = vm.apps.filter {
        (tab == 0 || (tab == 1 && it.isSystem) || (tab == 2 && !it.isSystem)) && it.label.contains(query, true)
    }
    Column(Modifier.fillMaxSize()) {
        PageHeader("Installed Apps", onBack = onBack, action = { IconButton(onClick = { query = if (query.isBlank()) " " else "" }) { Icon(Icons.Default.Search, null) } })
        SearchBar(query, { query = it }, {})
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
            listOf("All Apps", "System", "User").forEachIndexed { index, title -> Tab(tab == index, { tab = index }, text = { Text(title, fontSize = 12.sp) }) }
        }
        LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.weight(1f).padding(horizontal = 12.dp), contentPadding = PaddingValues(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list) { app -> AppTileLarge(app, vm) }
        }
        PrimaryGradientButton("＋ Add to Quick Launch", onQuick, Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
    }
}

@Composable
private fun AppTileLarge(app: AppInfo, vm: HubViewModel, showAdd: Boolean = true) {
    val context = LocalContext.current
    val icon = remember(app.packageName) { runCatching { context.packageManager.getApplicationIcon(app.packageName).toBitmap(128, 128).asImageBitmap() }.getOrNull() }
    Surface(Modifier.fillMaxWidth().height(112.dp), RoundedCornerShape(16.dp), color = Surface2, border = BorderStroke(1.dp, Color(0xFF1D4B8C))) {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().clickable { vm.launchApp(app) }.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                if (icon != null) Image(icon, null, Modifier.size(48.dp).clip(RoundedCornerShape(12.dp))) else Box(Modifier.size(48.dp).background(Blue, RoundedCornerShape(12.dp)))
                Spacer(Modifier.height(5.dp)); Text(app.label.take(15), fontSize = 11.sp, maxLines = 1)
            }
            if (showAdd) {
                Surface(
                    Modifier.align(Alignment.TopEnd).padding(5.dp).size(28.dp).clickable { vm.toggleFavoriteApp(app.packageName) },
                    CircleShape,
                    color = Color(0xCC071B32),
                    border = BorderStroke(1.dp, if (vm.favoriteAppPackages.contains(app.packageName)) Cyan else Purple)
                ) {
                    Icon(
                        if (vm.favoriteAppPackages.contains(app.packageName)) Icons.Default.Star else Icons.Default.Add,
                        null,
                        tint = if (vm.favoriteAppPackages.contains(app.packageName)) Cyan else Purple,
                        modifier = Modifier.padding(5.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun CustomShortcutScreen(vm: HubViewModel, onBack: () -> Unit) {
    var url by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf<String?>(null) }
    var browserPackage by remember { mutableStateOf<String?>(null) }
    var browserDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> imageUri = uri?.toString() }
    val browsers = remember {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))
        context.packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .distinctBy { it.activityInfo.packageName }
            .map { it.activityInfo.packageName to it.loadLabel(context.packageManager).toString() }
            .sortedBy { it.second.lowercase() }
    }

    Column(Modifier.fillMaxSize()) {
        PageHeader("Custom Shortcut (URL)", "Choose how this shortcut opens", onBack = onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Surface(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp), color = Surface1, border = BorderStroke(1.dp, Color(0xFF224B91))) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Enter URL", fontWeight = FontWeight.SemiBold)
                        TextField(url, { url = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("https://example.com") }, leadingIcon = { Icon(Icons.Default.Language, null) }, shape = RoundedCornerShape(14.dp), colors = fieldColors())
                        Spacer(Modifier.height(10.dp))
                        Text("Display Name", fontWeight = FontWeight.SemiBold)
                        TextField(name, { name = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Example") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, shape = RoundedCornerShape(14.dp), colors = fieldColors())
                        Spacer(Modifier.height(10.dp))
                        Text("Open With", fontWeight = FontWeight.SemiBold)
                        OutlinedButton(onClick = { browserDialog = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(browsers.firstOrNull { it.first == browserPackage }?.second ?: "Default Browser")
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("Icon", fontWeight = FontWeight.SemiBold)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(Icons.Default.Language, Icons.Default.Search, Icons.Default.Link, Icons.Default.Favorite, Icons.Default.Star, Icons.Default.Lock).forEach { icon ->
                                Surface(Modifier.size(42.dp), CircleShape, color = Color(0xFF0B2140), border = BorderStroke(1.dp, Purple)) {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Cyan) }
                                }
                            }
                            Surface(Modifier.size(42.dp).clickable { imagePicker.launch("image/*") }, CircleShape, color = Color(0xFF0B2140), border = BorderStroke(1.dp, Cyan)) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(Icons.Default.Download, null, tint = Cyan) }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Surface(Modifier.fillMaxWidth().height(135.dp), RoundedCornerShape(18.dp), color = Color(0xFF071A33), border = BorderStroke(1.dp, Color(0xFF254F90))) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                if (imageUri != null) rememberImageBitmap(imageUri)?.let { Image(it, null, Modifier.size(62.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop) }
                                else Icon(Icons.Default.Language, null, tint = Cyan, modifier = Modifier.size(52.dp))
                                Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(if (name.isBlank()) "Example" else name, fontWeight = FontWeight.Bold)
                                    Text(if (url.isBlank()) "https://example.com" else url, fontSize = 11.sp, color = Muted)
                                }
                            }
                        }
                    }
                }
            }
            item {
                PrimaryGradientButton(
                    "Save",
                    {
                        vm.addWebsite(name.ifBlank { "Website" }, url.ifBlank { "https://example.com" }, imageUri, browserPackage)
                        onBack()
                    }
                )
            }
        }
    }

    if (browserDialog) {
        AlertDialog(
            onDismissRequest = { browserDialog = false },
            title = { Text("Open With") },
            text = {
                Column {
                    TextButton(onClick = { browserPackage = null; browserDialog = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Default Browser", modifier = Modifier.fillMaxWidth())
                    }
                    browsers.forEach { (pkg, label) ->
                        TextButton(onClick = { browserPackage = pkg; browserDialog = false }, modifier = Modifier.fillMaxWidth()) {
                            Text(label, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { browserDialog = false }) { Text("Close") } }
        )
    }
}

@Composable
private fun QuickLaunchScreen(vm: HubViewModel, onBack: () -> Unit, onAddApp: () -> Unit, onAddWeb: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        PageHeader("Quick Launch", "Your favorite apps & shortcuts", onBack)
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
            Tab(tab == 0, { tab = 0 }, text = { Text("Apps") })
            Tab(tab == 1, { tab = 1 }, text = { Text("Shortcuts") })
        }
        if (tab == 0) {
            LazyVerticalGrid(columns = GridCells.Fixed(3), Modifier.weight(1f).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vm.quickLaunch.filter { it.type == "app" }) { entry -> vm.apps.firstOrNull { it.packageName == entry.key }?.let { AppTileLarge(it, vm) } }
                item { AddTile(onAddApp) }
            }
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(3), Modifier.weight(1f).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vm.quickLaunch.filter { it.type == "web" }) { entry -> vm.websites.firstOrNull { it.id.toString() == entry.key }?.let { WebsiteGridTile(it, vm) } }
                item { AddTile(onAddWeb) }
            }
        }
    }
}

@Composable
private fun WebsiteGridTile(web: WebsiteShortcut, vm: HubViewModel) {
    Surface(Modifier.fillMaxWidth().height(112.dp).clickable { vm.openWeb(web) }, RoundedCornerShape(16.dp), color = Surface2, border = BorderStroke(1.dp, Color(0xFF1D4B8C))) {
        Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { WebsiteIcon(web, Modifier.size(48.dp)); Spacer(Modifier.height(5.dp)); Text(web.name.take(15), fontSize = 11.sp) }
    }
}

@Composable
private fun AddTile(onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().height(112.dp).clickable { onClick() }, RoundedCornerShape(16.dp), color = Color.Transparent, border = BorderStroke(1.dp, Color(0xFF2A69B9))) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Add, null, tint = Cyan, modifier = Modifier.size(34.dp)); Text("Add", color = Cyan) } }
    }
}

@Composable
private fun MoreFeaturesScreen(vm: HubViewModel, onBackground: () -> Unit, onSettings: () -> Unit) {
    val rows = listOf(
        Triple(Icons.Default.Search, "Smart Search", "Find apps, tools & shortcuts instantly"),
        Triple(Icons.Default.Lock, "App Lock", "Protect your apps with password"),
        Triple(Icons.Default.AutoAwesome, "Theme Customization", "Change colors, style & background"),
        Triple(Icons.Default.CleaningServices, "Auto Clean", "Clear cache & junk files"),
        Triple(Icons.Default.History, "Recent Apps", "Quickly reopen your recent apps"),
        Triple(Icons.Default.WifiTethering, "Floating Badge", "See notifications at a glance"),
        Triple(Icons.Default.Save, "Backup & Restore", "Save your settings and data"),
        Triple(Icons.Default.TouchApp, "Gesture Support", "Use gestures for faster access")
    )
    Column(Modifier.fillMaxSize()) {
        PageHeader("More Features", onBack = onSettings, action = { RoundSmallAdd(onBackground) })
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(rows) { row ->
                Surface(Modifier.fillMaxWidth(), RoundedCornerShape(16.dp), color = Surface2, border = BorderStroke(1.dp, Color(0xFF1C4D93))) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Purple, Blue)), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(row.first, null, tint = Color.White) }
                        Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(row.second, fontWeight = FontWeight.SemiBold); Text(row.third, color = Muted, fontSize = 11.sp) }
                        Icon(Icons.Default.ArrowForward, null, tint = Color(0xFF8BB3FF))
                    }
                }
            }
        }
    }
}

@Composable
private fun BackgroundScreen(vm: HubViewModel, onBack: () -> Unit) {
    var selected by remember(vm.backgroundUri) { mutableStateOf(vm.backgroundUri) }
    var selectedType by remember(vm.backgroundType) { mutableStateOf(vm.backgroundType) }
    var animation by remember { mutableStateOf(vm.backgroundAnimation) }
    var speed by remember { mutableStateOf(vm.backgroundSpeed.toFloat()) }
    var brightness by remember { mutableStateOf(vm.backgroundBrightness.toFloat()) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selected = uri.toString()
            selectedType = if (uri.toString().lowercase().contains(".gif")) "gif" else "image"
        }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selected = uri.toString()
            selectedType = "video"
        }
    }

    Column(Modifier.fillMaxSize()) {
        PageHeader("Neo Animated Background", "Dynamic, smooth and modern", onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Surface(Modifier.fillMaxWidth().height(220.dp), RoundedCornerShape(22.dp), color = Surface1, border = BorderStroke(1.dp, BorderBrush())) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        if (selected != null) {
                            BackgroundMedia(selected!!, selectedType, Modifier.fillMaxSize(), brightness / 100f)
                        } else {
                            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF0D1D52), Color(0xFF5A12D6), Color(0xFF102B85))), RoundedCornerShape(22.dp)))
                        }
                        Row(Modifier.align(Alignment.BottomEnd).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { imagePicker.launch("image/*") }) { Text("Image / GIF") }
                            OutlinedButton(onClick = { videoPicker.launch("video/*") }) { Text("Video") }
                        }
                    }
                }
            }
            item {
                Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), color = Surface1, border = BorderStroke(1.dp, Color(0xFF224B91))) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Animation", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                            Switch(animation, { animation = it })
                        }
                        Text("Speed", color = Muted, fontSize = 12.sp)
                        Slider(speed, { speed = it }, valueRange = 10f..100f)
                        Text("${speed.toInt()}%", color = Cyan, fontSize = 11.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Glow / brightness", color = Muted, fontSize = 12.sp)
                        Slider(brightness, { brightness = it }, valueRange = 20f..100f)
                        Text("${brightness.toInt()}%", color = Cyan, fontSize = 11.sp)
                    }
                }
            }
            item {
                PrimaryGradientButton(
                    "Apply & Save",
                    { vm.setBackground(selected, animation, speed.toInt(), brightness.toInt(), selectedType); onBack() }
                )
            }
        }
    }
}

@Composable
private fun BackgroundMedia(uriString: String, type: String, modifier: Modifier, alpha: Float) {
    when (type) {
        "video" -> {
            AndroidView(
                modifier = modifier.alpha(alpha),
                factory = { ctx ->
                    VideoView(ctx).apply {
                        setVideoURI(Uri.parse(uriString))
                        setOnPreparedListener { player ->
                            player.isLooping = true
                            player.setVolume(0f, 0f)
                            start()
                        }
                    }
                },
                update = { view ->
                    if (!view.isPlaying) view.start()
                }
            )
        }
        else -> {
            AndroidView(
                modifier = modifier.alpha(alpha),
                factory = { ctx ->
                    ImageView(ctx).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        if (Build.VERSION.SDK_INT >= 28 && type == "gif") {
                            runCatching {
                                val source = ImageDecoder.createSource(ctx.contentResolver, Uri.parse(uriString))
                                drawable = ImageDecoder.decodeDrawable(source)
                                if (drawable is android.graphics.drawable.AnimatedImageDrawable) {
                                    (drawable as android.graphics.drawable.AnimatedImageDrawable).start()
                                }
                            }
                        } else {
                            runCatching {
                                ctx.contentResolver.openInputStream(Uri.parse(uriString))?.use { input ->
                                    setImageBitmap(BitmapFactory.decodeStream(input))
                                }
                            }
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun SettingsScreen(vm: HubViewModel, onBack: () -> Unit) {
    var showPhoneSettings by remember { mutableStateOf(false) }
    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setLogoUri(uri.toString())
    }
    Column(Modifier.fillMaxSize()) {
        PageHeader("Settings", "Alpha Hub preferences", onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                SettingsGroupTitle("Header")
                Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), color = Surface1, border = BorderStroke(1.dp, Color(0xFF224B91))) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Alpha Imperium logo", fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val logo = rememberImageBitmap(vm.logoUri)
                            if (logo != null) Image(logo, null, Modifier.size(58.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                            else Image(painterResource(com.alphaimperium.alphahub.R.drawable.alpha_logo), null, Modifier.size(58.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                            Spacer(Modifier.width(12.dp))
                            OutlinedButton(onClick = { logoPicker.launch("image/*") }) { Text("Choose from Gallery") }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("Title size: ${vm.titleSize}sp", color = Muted, fontSize = 12.sp)
                        Slider(vm.titleSize.toFloat(), { vm.setTitleSize(it.toInt()) }, valueRange = 20f..40f)
                        Text("Title color", color = Muted, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("00E5FF", "FFFFFF", "8B5CFF", "7CB7FF").forEach { hex ->
                                Surface(
                                    Modifier.size(34.dp).clickable { vm.setTitleColorHex(hex) },
                                    CircleShape,
                                    color = runCatching { Color(android.graphics.Color.parseColor("#$hex")) }.getOrDefault(Cyan),
                                    border = BorderStroke(2.dp, if (vm.titleColorHex == hex) Color.White else Color.Transparent)
                                ) {}
                            }
                        }
                    }
                }
                SettingsSwitch("Logo animation", "Animate the Alpha Imperium logo on Home", vm.logoAnimation, vm::setLogoAnimation)
                SettingsSwitch("Title glow", "Add subtle glow to ALPHA HUB title", vm.titleGlow, vm::setTitleGlow)
                SettingsSwitch("Subtitle", "Show the customizable Home subtitle", vm.subtitleEnabled, vm::setSubtitleEnabled)
                SettingsSwitch("Glass UI", "Use transparent glass panels above the background", vm.glassEnabled, vm::setGlass)
                SettingsSwitch("Blur effect", "Keep the glass layer visually separated", vm.blurEnabled, vm::setBlur)
                SettingsSwitch("Neon borders", "Show blue/purple/cyan panel borders", vm.neonBorderEnabled, vm::setNeonBorder)
            }
            item {
                Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), color = Surface1, border = BorderStroke(1.dp, Color(0xFF224B91))) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Home title", fontWeight = FontWeight.SemiBold)
                        TextField(vm.titleText, vm::setTitleText, modifier = Modifier.fillMaxWidth(), colors = fieldColors(), shape = RoundedCornerShape(14.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Subtitle text", fontWeight = FontWeight.SemiBold)
                        TextField(vm.subtitleText, vm::setSubtitleText, modifier = Modifier.fillMaxWidth(), colors = fieldColors(), shape = RoundedCornerShape(14.dp))
                    }
                }
            }
            item {
                SettingsGroupTitle("Search & Interaction")
                SettingsSwitch("Voice search", "Enable microphone search", vm.voiceSearchEnabled, vm::setVoiceSearch)
                SettingsSwitch("Search history", "Keep optional recent query history", vm.searchHistoryEnabled, vm::setSearchHistory)
                SettingsSwitch("Animations", "Enable UI and background motion", vm.animationsEnabled, vm::setAnimations)
                SettingsSwitch("Compact mode", "Use denser cards and rows", vm.compactMode, vm::setCompact)
            }
            item {
                Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), color = Surface1, border = BorderStroke(1.dp, Color(0xFF224B91))) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Panel opacity", fontWeight = FontWeight.SemiBold)
                        Slider(value = vm.panelOpacity.toFloat(), onValueChange = { value -> vm.setOpacity(value.toInt()) }, valueRange = 60f..100f)
                        Text("${vm.panelOpacity}%", color = Cyan, fontSize = 12.sp)
                    }
                }
            }
            item {
                SettingsGroupTitle("Home & Quick Access")
                SettingsSwitch("Recent", "Automatically record apps and websites opened through Alpha Hub", vm.recentsEnabled, vm::setRecents)
                SettingsSwitch("Left action rail", "Show customizable quick-access slots", vm.railEnabled, vm::setRailEnabled)
                ActionSettingsRow("Phone Settings", "Choose which Android settings appear on Home", Icons.Default.Tune) { showPhoneSettings = true }
                ActionSettingsRow("Neo Animated Background", "Image, GIF or video background", Icons.Default.Image) {
                    onBack()
                }
            }
            item {
                SettingsGroupTitle("Background & Visuals")
                Text("Background and visual-layer controls are kept separate from core data, so changing appearance does not remove favorites or recents.", color = Muted, fontSize = 12.sp)
            }
            item {
                SettingsSwitch("Floating Badge", "Allow a floating quick-launch trigger", vm.bubbleEnabled, vm::setBubble)
            }
            item {
                OutlinedButton(onClick = vm::clearRecents, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, Purple)) {
                    Icon(Icons.Default.Delete, null); Spacer(Modifier.width(6.dp)); Text("Clear Recent History")
                }
            }
        }
    }

    if (showPhoneSettings) {
        PhoneSettingsPickerDialog(vm) { showPhoneSettings = false }
    }
}

@Composable
private fun SettingsGroupTitle(title: String) {
    Text(title.uppercase(), color = Cyan, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun SettingsSwitch(title: String, desc: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Surface(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), color = Surface1, border = BorderStroke(1.dp, Color(0xFF224B91))) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(desc, fontSize = 11.sp, color = Muted) }
            Switch(checked, onCheckedChange = onChecked)
        }
    }
}

@Composable
private fun ActionSettingsRow(title: String, desc: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = onClick), RoundedCornerShape(18.dp), color = Surface1, border = BorderStroke(1.dp, Color(0xFF224B91))) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(desc, fontSize = 11.sp, color = Muted) }; Icon(Icons.Default.ArrowForward, null, tint = Cyan)
        }
    }
}

@Composable
private fun ShortcutsScreen(vm: HubViewModel, onAdd: () -> Unit, onQuick: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        PageHeader("Shortcuts", "Web favorites and quick links", onBack = onBack, action = { RoundSmallAdd(onAdd) })
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { PrimaryGradientButton("＋ Add Website Shortcut", onAdd, Modifier.padding(horizontal = 14.dp)) }
            item { PrimaryGradientButton("Open Quick Launch", onQuick, Modifier.padding(horizontal = 14.dp), purple = true) }
            items(vm.websites) { web ->
                Surface(Modifier.fillMaxWidth().padding(horizontal = 14.dp), RoundedCornerShape(18.dp), color = Surface2, border = BorderStroke(1.dp, Color(0xFF1D4C8E))) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        WebsiteIcon(web, Modifier.size(52.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(web.name, fontWeight = FontWeight.SemiBold); Text(web.url, color = Muted, fontSize = 11.sp) }
                        IconButton(onClick = { vm.toggleFavorite(web.id) }) { Icon(if (web.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Color(0xFFFFC928)) }
                        IconButton(onClick = { vm.removeWebsite(web.id) }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFFF6C93)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomNavigation(current: HubScreen, onSelect: (HubScreen) -> Unit) {
    val items = listOf(
        Triple(HubScreen.HOME, Icons.Default.Home, "Home"),
        Triple(HubScreen.TOOLS, Icons.Default.Build, "Tools"),
        Triple(HubScreen.APPS, Icons.Default.GridView, "Apps"),
        Triple(HubScreen.SHORTCUTS, Icons.Default.Language, "Shortcuts")
    )
    Surface(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp), RoundedCornerShape(28.dp), color = Color(0xD9030B19), border = BorderStroke(1.dp, Brush.linearGradient(listOf(Blue, Purple)))) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            items.forEach { (screen, icon, label) ->
                val selected = current == screen
                Column(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).clickable { onSelect(screen) }.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(icon, null, tint = if (selected) Cyan else Color(0xFF8A98C8), modifier = Modifier.size(26.dp))
                    Text(label, color = if (selected) Cyan else Color(0xFF8A98C8), fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                    if (selected) Box(Modifier.padding(top = 3.dp).width(56.dp).height(3.dp).clip(CircleShape).background(Cyan))
                }
            }
        }
    }
}

@Composable
private fun RoundSmallAdd(onClick: () -> Unit) {
    Surface(Modifier.size(42.dp), CircleShape, color = Color(0x33102644), border = BorderStroke(1.dp, Cyan)) { IconButton(onClick = onClick) { Icon(Icons.Default.Add, null, tint = Cyan) } }
}

@Composable
private fun PrimaryGradientButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, purple: Boolean = false) {
    Button(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().height(50.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (purple) Purple else Blue, contentColor = Color.White)
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
private fun fieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = Color(0xFF081A31),
    unfocusedContainerColor = Color(0xFF081A31),
    focusedIndicatorColor = Cyan,
    unfocusedIndicatorColor = Color(0xFF234E96),
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    cursorColor = Cyan
)

@Composable
private fun rememberImageBitmap(uriString: String?): ImageBitmap? {
    val context = LocalContext.current
    return produceState<ImageBitmap?>(initialValue = null, uriString) {
        value = uriString?.let { uri ->
            runCatching {
                context.contentResolver.openInputStream(Uri.parse(uri))?.use { stream -> BitmapFactory.decodeStream(stream)?.asImageBitmap() }
            }.getOrNull()
        }
    }.value
}

private fun BorderBrush(): Brush = Brush.linearGradient(listOf(Blue, Purple))
