# Alpha Hub — Part 1 integrated source

This build is the first implementation pass of the finalized Page 1 specification.

## Implemented in this pass

1. Home header with Alpha Imperium logo, configurable title/subtitle, logo replacement from Gallery, title size/color, glow, glass/neon controls.
2. Universal Search across installed apps, websites and Phone Settings, plus microphone entry point.
3. Favorite Apps with persistence, dynamic installed-app detection and add/remove controls.
4. Favorite Websites with custom icons, persistence and per-shortcut browser selection.
5. Combined Recent history with duplicate suppression, persistence and Clear control.
6. Phone Settings shortcuts with an Add/manage dialog and Android Settings intents.
7. Left Action Rail with Tools, Screen Translation, five customizable slots, Edit mode and Back.
8. Bottom Navigation for Home / Tools / Apps / Shortcuts.
9. Responsive Home scrolling, glass/neon cards and unified Alpha Hub navigation.
10. Background layer supports image/GIF/video selection, animation and brightness controls; appearance settings are stored independently of functional data.

## Persistence

SharedPreferences stores favorites, websites, recent history, phone settings, rail slots, background selection and visual settings.

## Build

Open `AlphaHub-Reconstruction` in the existing Codespace and run the normal debug build used for the project. The repository intentionally excludes generated `build/` output from this integration ZIP.
